# Underwater Acoustic Research Code (V6)

Canonical runnable research package (17 science scripts + site-context summary).
Competition data, VTUAD WAV audio, and saved assessment predictions are NOT included.

## 1. Environment
Install pinned dependencies from `requirements.txt` (tested on Python 3.13).

## 2. Site-Context Figure (Figure 4)
```bash
python scripts/build_site_context_figure.py \
  --archive /PATH/TO/South_African_Real_Acoustics.zip \
  --summary site_context/training_only_site_aggregates.csv \
  --output site_context_candidate_locations.png
```

## 3. Experiment 007 Decision-Gate Audit (Table 2)
```bash
python scripts/audit_experiment007_decision_gate_v1.py --self-test-only
python scripts/audit_experiment007_decision_gate_v1.py \
  --input /PATH/TO/reports/baselines/experiment007_source_disjoint_v1 \
  --output ./exp007_gate_out
```

## 4. Six-Station Descriptive Appendix (Table 1 & Figures 1-3, 5-6)
Requires `reports/audits/real_acoustic_development_v1/` and
`reports/research_manuscript_v1/station_relative_anomaly_proxy.csv`:
```bash
python scripts/build_real_acoustic_results_v2.py --root . --output ./real_acoustic_out
python scripts/verify_real_acoustic_results_v2.py --root . --output ./real_acoustic_out
```

## Limits
Archive levels are uncalibrated source-export dB (not dB re 1 uPa). Coordinates in
`stations.csv` are working site candidates without confirmed vessel-event labels.
